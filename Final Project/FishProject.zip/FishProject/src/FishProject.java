import java.awt.Label;
import java.awt.TextField;
import javafx.application.Application;
import javafx.scene.*;
import javafx.stage.Stage;
import javafx.geometry.Pos;
import javafx.event.ActionEvent;
import javajx.event.EventHandler;

public class FishProject extends Application{

	public void start(Stage stage) {
		MenuBar bar = new MenuBar();
		Menu operation = new Menu("Fish Index");
		MenuItem exit = new MenuItem("Exit");
		MenuItem enter = new MenuItem("Enter a Fish:");
		operation.getItems().addAll(enter, exit);
		
		bar.getMenus().add(operation);
		
		GridPane container = new GridPane();
		container.setVgap(3);
		
		Label fishName = new Label(String.format("%-30s", "Fish Name: "));
		TextField nameFish = new TextField();
		nameFish.setPrefColumnCount(3);
		container.add(fishName, 0, 0);
		container.add(nameFish, 1, 0);
		
		Label fishLength = new Label(String.format("%-30s", "Fish Length: "));
		TextField lengthFish = new TextField();
		lengthFish.setPrefColumnCount(3);
		container.add(fishLength, 0, 1);
		container.add(fishLength, 1, 1);
		
		Label fishWeight = new Label(String.format("%-30s", "Fish Weight: "));
		TextField weightFish = new TextField();
		weightFish.setPrefColumnCount(3);
		container.add(fishWeight, 0, 2);
		container.add(weightFish, 1, 2);
		
		Button stats = new Button("Show Stats");
		HBox statsContain = new Hbox(stats);
		statsContain.setAlignment(Pos.BOTTOM_LEFT);
		
		VBox main = new VBox(6, bar, container,400, 200);
		Scene scene = new Scene(main, 300, 200);
		stage.setScene(scene);
		stage.setTitle("Exercise31_17");
		stage.show();
		
		EventHandler<ActionEvent> eventStat = e -> {
			double fish, length, weight;
			try {
				fish = nameFish.getText().trim();
				length = Double.parseDouble(lengthFish.getText().trim());
				weight = Double.parseDouble(weightFish.getText().trim());
				System.out.println("Your Fish Stats: ");
				System.out.println("Fish Name: " + nameFish + "Fish Length: " + lengthFish + " Fish Weight: " + weightFish);
			}
			catch(Exception exception) {
				System.out.println("Input is not valid please type in a valid value.");
			}
		};
		stats.setOnAction(eventStat);
		enter.setOnAction(eventStat);
		
		exit.setOnAction(e -> System.exit(0));
		
		
	}
}
