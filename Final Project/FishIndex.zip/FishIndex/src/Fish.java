
public class Fish {
	double weight = 0;
	String length = "";
	public Fish(String d, double e) {
		weight = e;
		length = d;
		
	}
	public void rainbowTrout(String weight, double length) {
		System.out.println("Your Rainbow Trout stats: " + "\t" + "Weight: " + weight + "Length:" + length);
		
	}
	public void Catfish(String weight, double length) {
		System.out.println("Your Catfish stats: " + "\t" + "Weight: " + weight + "Length:" + length);
		
	}
	public void blueGill(String weight, double length) {
		System.out.println("Your Blue Gill stats: " + "\t" + "Weight: " + weight + "Length:" + length);
		
	}
	public void brookTrout(String weight, double length) {
		System.out.println("Your Brook Trout stats: " + "\t" + "Weight: " + weight + "Length:" + length);
		
	}
}
