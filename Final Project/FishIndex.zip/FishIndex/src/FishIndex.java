import java.util.Scanner;

public class FishIndex {
	
	
	static double length = 0;
	static double weight = 0;
	static String name = "";
	static Scanner input = new Scanner(System.in);
	static String[] fishTypes = { "Rainbow Trout", "Catfish", "Blue Grill", "Brook Trout" };
	static Fish[] allFish = new Fish[50];
	
	public static void main(String[] args) {
		runProgram();
	}
	
	public static double getFishLengthFromUser(){
		System.out.println("Length: ");
		return  input.nextDouble();
	}

	public static double getFishWeightFromUser() {
		System.out.println("Please enter the length and weight of your catch!");
		System.out.println("Weight: ");
		return input.nextDouble();
	}
	
	public static String getFishNameFromUser() {
		System.out.println("Enter the name of your fish: ");
		return input.next();
	}
	
	public static int getFishIndexFromUser() {
		System.out.println("Please choose from the following possibilities: ");
		System.out.println("1:" + fishTypes[0] + " \t 2:" + fishTypes[1] + "\t 3:" + fishTypes[2] + "\t 4:"
				+ fishTypes[3] + "\t 5: Exit ");

		return input.nextInt();
	}
	
	public static void runProgram() {
		System.out.println("Welcome to the Fish Index!");
		
		
		int menu = getFishIndexFromUser();
		int fishIndex = 0;
		while (menu != 5) {
			length = getFishLengthFromUser();
			weight = getFishWeightFromUser();
			Fish myFish = new Fish(length, weight, fishTypes);
	
			allFish[fishIndex] = myFish;
			
			fishIndex++;
			menu = getFishIndexFromUser();
		}
	}
}