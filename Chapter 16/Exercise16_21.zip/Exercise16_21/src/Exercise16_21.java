import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.application.Application;
import javafx.animation.Timeline;
import javafx.util.Duration;
import javafx.stage.Stage;
import javafx.scene.text.Font;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.Media;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.Pane;
import javafx.scene.control.TextField;
import javafx.scene.Scene;
import javafx.geometry.Pos;

public class Exercise16_21 extends Application {
	
	final String URL = "http://liveexample.pearsoncmg.com/common/sample.mp4";
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		
		TextField textCountDown = new TextField("0");
		textCountDown.setFont(Font.font(50));
		textCountDown.setPrefColumnCount(4);
		textCountDown.setAlignment(pos.CENTER);
		textCountDown.setFocusTraversable(false);
		BorderPane pane = new BorderPane(textCountDown);
		StackPane stackpane = new StackPane(pane);
		
		Timeline timeline = new Timeline(
				new KeyFrame(Duration.millis(1000), e-> {
					textCountDown.setText((Integer.parseInt(textCoundDown.getText())-1) + "");
					
				}));
		textCountDown.setOnAction(e-> {
			if (timeline.getStatus() == Animation.Status.RUNNING) {
				timeline.stop();
			}
			timeline.setCycleCount(Integer.parseInt(textCountDown.getText()));
			textCountDownsetEditable(false);
			timeline.play();
		});
		
		File file = new File(URL);
		MediaPlayer mediaPlayer = new MediaPlayer(new Media(file.toURI().toString()));
		
		timeline.setOnFinished(event -> {
			mediaPlayer.play();
		});
		primaryStage.setScene(new Scene(stackPane));
		primaryStage.setTitle("Countdown");
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}

}
