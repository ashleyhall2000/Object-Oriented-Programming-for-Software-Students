import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
public class Exercise16_01 extends Application{
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		
		RadioButton rbRed = new RadioButton("Red");
		RadioButton rbYellow = new RadioButton("Yellow");
		RadioButton rbBlack = new RadioButton("Black");
		RadioButton rbOrange = new RadioButton("Orange");
		RadioButton rbGreen = new RadioButton("Green");
		
		ToggleGroup group = new ToggleGroup();
		rbRed.setToggleGroup(group);
		rbYellow.setToggleGroup(group);
		rbBlack.setToggleGroup(group);
		rbOrange.setToggleGroup(group);
		rbGreen.setToggleGroup(group);
		
		BorderPane pane = new BorderPane();
		HBox rbhbox = new HBox(8);
		rbhbox.getChildren().addAll(rbRed, rbYellow, rbBlack, rbOrange, rbGreen);
		rbhbox.setAlignment(Pos.CENTER);
		pane.setTop(rbhbox);
	
		
		Pane textpane = new BorderPane();
		Text text = new Text(25, 25, "Programming is Fun!!!");
		test.setFont(new Font("Times New Roman", 24));
		textpane.getChildren().add(text);
		textpane.setStyle("-fx-border-color: pink");
		pane.setCenter(textpane);
		
		Hbox hbox1 = new Hbox(8);
		Button leftbutton = new Button(" <= ");
		Button rightbutton = newButton(" => ");
		hbox1.getChildren().addAll(leftbutton, rightbutton);
		hbox1.setAlignment(Pos.CENTER);
		pane.setBottom(hbox1);
		
		Scene scene = new Scene(pane, 600, 600);
		primaryStage.setTitle("Exercise 16_01");
		primaryStage.setScene(scene);
		primaryStage.show();
		
	}

	public static void main(String[] args) {
		

	}

}
