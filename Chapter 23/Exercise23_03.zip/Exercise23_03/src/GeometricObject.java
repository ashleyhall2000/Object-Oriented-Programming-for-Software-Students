
public class GeometricObject {

}
