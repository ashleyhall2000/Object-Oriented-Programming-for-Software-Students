
public class GeometricObjectComparator {

}
