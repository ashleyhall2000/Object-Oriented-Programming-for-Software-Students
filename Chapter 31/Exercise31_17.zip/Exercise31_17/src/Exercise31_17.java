import java.awt.TextField;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javajx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Hbox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Exercise31_17 {

	public void start(Stage stage) {
		MenuBar bar = new Menubar();
		Menu menuOps = new Menu("Operation");
		MenuItem exit = new MenuItem("Exit");
		MenuItem calculate = new MenuItem("Calculate");
		menuOps.getItems().addAll(calculate, exit);
		
		bar.getMenus().add(menuOps);
		
		GridPane contain = new GridPane();
		contain.setVgap(5);
		Label investmentAmount = new Label(String.format("%-30s", "Investment Amount: "));
		TextField investment = new TextField();
		investment.setPrefColumnCount(12);
		contain.add(investmentAmount, 0,0);
		contain.add(investment, 1, 0);
		
		Label numYears = new Label(String.format("%-30s", "Number of Years: "));
		TextField yearAmount = new TextField();
		contain.add(investmentAmount, 0, 1);
		contain.add(investment, 1, 1);
		
		Label interestRate = new Label(String.format("%-30s", "Annual Interest Rate: "));
		TextField interest = new TextField();
		contain.add(interestRate, 0, 2);
		contain.add(interest, 1, 2);
		
		Label totalvalue = new Label(String.format("%-30s", "Future Value: "));
		TextField total = new TextField();
		total.setPrefColumnCount(12);
		total.setEditable(false);
		contain.add(totalValue, 0, 3);
		contain.add(total, 1, 3);
		
		Button calc = new Button("Calculate");
		Hbox calContain = new Hbox(calc);
		calContain.setAlignment(Pos.BOTTOM_RIGHT);
		
		Vbox main = new VBox(5, bar, contain, calContain);
		Scene scene = new Scene(mainPane, 300, 200);
		stage.setScene(scene);
		stage.setTitle("Exercise31_17");
		stage.show();
		
		EventHandler<ActionEvent> eventCalc = e -> {
			double amount, rate, years;
			try {
				amount = Double.parseDouble(investment.getText().trim());
				rate = Double.parseDouble(interest.getText().trim());
				years = Double.parseDouble(yearAmount.getText().trim());
				double doubleTotal = amount * Math.pow(1 + rate/1200, years * 12);
				total.setText("$" + doubleTotal);
			}
			catch(Exception exception) {
				total.setText("Please type a value that is valid!");
			}
		};
		calc.setOnAction(calculateEvent);
		calculate.setOnAction(calculateEvent);
		
		exit.setOnAction(e -> System.exit(0));
	}
}
