import java.util.List;
import java.util.Scanner;
import java.util.*;
public class Exercise20_3 {

	public static void main(String[] args) {
	
		Scanner input = new Scanner(System.in);
		int correct = 0;
		
		String[][] states = new String[][] {
				{"Alabama", "Montgomery"},
				{"California", "Sacramento"},
				{"Hawaii", "Honolulu"},
				{"Florida", "Tallahasse"},
				{"Nevada", "Carson City"},
				{"New York", "Albany"},
				{"Utah", "Salt Lake City"},
				{"Maine", "Augusta"},
				{"Lousiana", "Baton Rouge"},
				{"Texas", "Austin"}};
				
				// Array list conversion
				List<String[]> list = Arrays.asList(states);
				//shuffle Array list
				Collections.shuffle(list);
//				
				//arraylist.add
				//arraylist.get(spot you are getting);
		
				
				for(int i = 0; i < states.length; i++) {
					System.out.println("What is the capital of " + states[i][0] +"?");
					String answer = input.nextLine();
					if(answer.equalsIgnoreCase(states[i][1])) {
						System.out.println("Your answer is correct!");
						correct++;
					}
				}
				
				System.out.println("The correct count is " + correct);
		}
		

	}

