package exercise15;

import java.awt.Color;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.time.Duration;
import javafx.application.*;
import javafx.scene.*;
import javafx.animation.*;
import javafx.stage.*;
import javafx.scene.layout.*;
import javafx.animation.FadeTransition;
import javafx.animation.PathTransition;
import javafx.animation.Timeline;

public class exercise15 extends Application {
	@Override
	public void start(Stage primaryStage) {
		BorderPane pane = new BorderPane();
		
		Rectangle rectangle = new Rectangle(2,2,9,9);
		rectangle.setFill(Color.PINK);
		
		Polygon polygon = new Polygon();
		polygon.setFill(Color.PURPLE);
		polygon.setStroke(Color.BLACK);
		
		pane.getChildren().add(polygon);
		pane.getChildren().add(rectangle);
		
		PathTransition pt = new PathTransition();
		pt.setDuration(Duration.ofMillis(5000));
		pt.setPath(polygon);
		pt.setNode(rectangle);
		pt.setOrientation(PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);
		pt.setCycleCount(Timeline.INDEFINITE);
		pt.setAutoReverse(true);
		pt.play();
		
		polygon.setOnMousePressed(e -> pt.pause());
		polygon.setOnMousePressed(e -> pt.play());
		
		FadeTransition ft = new FadeTransition(Duration.ofMillis(5000), rectangle);
		ft.setFromValue(1.5);
		ft.setToValue(0.5);
		ft.setCycleCount(Timeline.INDEFINITE);
		ft.setAutoReverse(true);
		ft.play();
		
		rectangle.setOnMousePressed(e -> pt.pause());
		rectangle.setOnMousePressed(e -> pt.play());
		
		Scene scene = new Scene(pane, 300, 250);
		primaryStage.setTitle("Rectangle on a Polygon");
		primaryStage.setscene(scene);
		primaryStage.show();
		
	}

	public static void main(String[] args) {
		launch(args);
	}
}
