//import javafx.scene.layout.Hbox;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
public class BallPane extends Application {
		
	public void start(Stage primaryStage) throws Exception {
		Button btLeft = new Button("Left");
		Button btRight = new Button("Right");
		Button btUp = new Button("Up");
		Button btDown = new Button("Down");
		Circle ball = new Circle(75, 40, 5);
		ball.setFill(Color.PINK);
		ball.setStroke(Color.BLACK);
		
		HBox buttons = new HBox(10);
		buttons.getChildren().addAll(btLeft, btRight, btUp, btDown);
		buttons.setAlignment(Pos.CENTER);
		BorderPane borderpane = new BorderPane();
		borderpane.setCenter(ball);
		borderpane.setBottom(buttons);
		BorderPane.setAlignment(buttons, Pos.TOP_CENTER);
		
		Scene scene = new Scene(borderpane, 300, 150);
		primaryStage.setTitle("Exercise15_03");
		primaryStage.setScene(scene);
		primaryStage.show();
//		
//		btLeft.setOnAction(e -> {ball.left();});
//		btRight.setOnAction(e -> {ball.right();});
//		btLeft.setOnAction(e -> {ball.up();});
//		btLeft.setOnAction(e -> {ball.down();});
//		
//		
		btLeft.setOnMouseClicked(e -> {
			ball.setCenterX(ball.getCenterX() - 30);
		});
		btRight.setOnMouseClicked(e -> {
			ball.setCenterX(ball.getCenterX() + 30);
		});
		btUp.setOnMouseClicked(e -> {
			ball.setCenterY(ball.getCenterY() + 30);
		});
		btDown.setOnMouseClicked(e -> {
			ball.setCenterY(ball.getCenterY() - 30);
		});
	}

	public static void main(String[] args) {
		launch(args);

		}

//	public void BallPane(){
//		
//	}
//
//	public void left() {
//		
//	}
//	public void right() {
//		
//	}
//	public void up() {
//		
//	}
//	public void down() {
//		
//	}
}