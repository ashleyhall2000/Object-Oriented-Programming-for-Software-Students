import java.io.*;

public class Exercise17_03 {

	public static void main(String[] args) {
		
		String[] packageParts = Exercise17_03.class.getPackage().getName().split("\\.");
		String filePath = packageParts[0] + File.separator + packageParts[1] + File.separator + "Exercise17_03.dat";
		if(!(new File(filePath).exists())) {
			try (FileOutputStream fo = new FileOutputStream(filePath)) {
				DataOutputStream dos = new DataOutputStream(fo);
				runCreateTestDatFile(dos);
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println(e.getLocalizedMessage());
				
			}
			try (FileInputStream fi = new FileInputStream(filePath)) {
				DataInputStream di = new DataInputStream(fi);
				
				int total = 0;
				int numbers = di.available() / 4;
				System.out.print("The sum: ");
				for(int i = 0; i < numbers; i++) {
					int num = di.readInt();
					if (i == 0) {
						System.out.println(num + "");
					} else {
						System.out.println(" + " + num);
					}
					total += num;
				}
				System.out.println(" = " + total);
			} catch (IOException e) {
				e.printStackTrace();
			}
			}
		}
		static void runCreateTestDatFile(DataOutputStream dos) throws IOException {
			for (int i = 0; i < 10; i++) {
				int n = (int) (1 + Math.random() * 10);
				dos.writeInt(n);
			}
			dos.flush();
			dos.close();
		}
}
