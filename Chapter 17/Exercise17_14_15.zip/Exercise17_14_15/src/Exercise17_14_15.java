import java.io.*;
import java.util.Scanner;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
public class Exercise17_14_15 {

	public static void main(String[] args) {
		String NEW_DIR = "chapter_17" + File.separator + "exercise17_14";
				Scanner input = new Scanner(System.in);
			String inFileStream = input.next();
			File inputFile = new File(NEW_DIR,inFileStream);
			
			System.out.println("Enter a name for the ouput file: ");
			String outFileStream = input.next();
			
			System.out.println("Enter an input for the file name that will be decrypted: ");
			String inputFileStream = input.next();
			
			File outputFile = new File(NEW_DIR, outFileStream);
			try (BufferedOutputStream bufferedOutputStream - new BufferedOutputStream(new FileOutputStream(outputFile))) {
				try {
					byte[] inBytes = Files.readAllBytes(input.File.toPath());
					for (byte b : inBytes) {
						bufferedOutputStream.write(b + 5);
					}
					bufferedOutputStream.flush();
					bufferedOutputStream.close();
				} catch (IOException ioException) {
					ioException.printStackTrace();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			input.close();

	}

}

