import java.io.*;

public class Exercise17_07 {

	public static void main(String[] args) {
		
		String[] packageParts = Exercise17_07.class.getPackage().getName().split("\\.");
		String path = packageParts[0] + File.separator + packageParts[1] + File.separator + "Exercise17_07" + ".dat";
		
		File outFile = new File(path);
		if (!outFile.exists()) {
			writeLoanObjs(outFile);
		}
		handleRead(outFile);

	}
	static void handleRead(File file) {
		try {
			double loan = readLoanObjects(file);
			System.out.printf("Total loan about is %.2f", loan);
			
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Could not read loan objects...");
		} catch (ClassNotFoundException ce) {
			ce.printStackTrace();
			System.out.println("Could not recognize loan object class...");
		}
	}
	static double readLoanObjects(File file) throws ClassNotFoundException, IOException {
		double sum = 0;
		try (ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream(file))) {
			
		}
		while (true) {
			Loan loan = (Loan) objectInputStream.readObject();
			System.out.priontln("Adding to loan amount" + loan.getLoanAmount() + "to loan total");
			sum += loan.getLoanAmount();
		}
		
	}catch (EOFException eofException ) {
		System.out.println("End of the file...");
	}
	return sum;
	static void writeLoanObjs (File file) {
		Loan l1 = new Loan (6.5, 10, 210320);
		Loan l2 = new Loan (4.7, 10, 93800);
		Loan l3 = new Loan (3.9, 10, 50230);
		Loan l4 = new Loan (11.5, 10, 21000);
		Loan l5 = new Loan (2.5, 10, 172000);
		
		try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(file))) {
			output.writeObject(l1);
			output.writeObject(l2);
			output.writeObject(l3);
			output.writeObject(l4);
			output.writeObject(l5);
			
		} catch (IOException ioException) {
			ioException.printStackTrace();
		}
	}

}
