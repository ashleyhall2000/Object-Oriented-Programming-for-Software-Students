import java.io.*;
import java.util.Random;
public class Exercise17_01 {
	
	public static void main(String[] args) {
		String[] packageParts = Exercise17_01.class.getPackage().getName().split("\\.");
		String filePath = packageParts[0] + File.separator + packageParts[1] + File.separator + "Exercise17_01";
		
		File file = new File(filePath);
		PrintWriter printWriter = null;
		try {
			if(file.exists()) {
				printWriter = new PrintWriter(new FileOutputStream(new File(filePath), false));
			} else {
				printWriter = new PrintWriter(file);
			}
			StringBuilder build = new StringBuilder();
			Random random = new Random();
			
			for (int i = 0; i < 100; i++) {
				int number = random.nextInt(100);
				build.append(number).append("  ");
				
			}
			printWriter.write(build.toString());
			printWriter.close();
			System.out.println("Random integers have been generated successfully.");
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("FileNotFound error.");
		}
	
		

	}

}
