import java.util.Scanner;
import java.io.File;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.ArrayList;

public class Exercise12_15 {
	public static void main(String[] args) {
	
		File file = new File("Exercise12_15.txt");
		if(file.exists()) {
			System.out.println("This file already exists!");
			System.exit(0);
			}
		try( PrintWriter output = new PrintWriter(file));
				}
	
	for( int i = 0; i < 100; i++) {
		output.print((int) * (Math.random() * 500) +1);
		output.print(" ");
	}

	static ArrayList<Integer> lines = new ArrayList<>();
	
	try( Scanner input = new Scanner(file));
			{
	while(input.hasNext()) {
		list.add(input.nextInt());
		}
	}
Collections.sort(list);
System.out.println(list.toString());
System.out.println();
}