import java.util.Random;
import java.util.Scanner;

public class Exercise12_03 {
static Scanner input = new Scanner(System.in);
static int i = 0;
	public static void main(String[] args) {
		
		Random random = new Random();
		
		
		int[] array = getArray(); 
		
		
		System.out.println("Enter an index: ");
		
		System.out.println("Element value: " + array[input.nextInt()]);
		if(i >= 100) {
			System.out.println("Out Of Bounds");
			}
		}
	 static int[] getArray() {
		 int[] array = new int[100];
		 for(int i = 0; i < array.length; i++) {
				array[i] = (int)(Math.random() * 100) +1;
		 }
		return array;
	 }
}
