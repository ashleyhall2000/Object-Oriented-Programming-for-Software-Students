import java.util.Scanner;

public class Exercise22_03 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a string s1: ");
		String s1 = scanner.nextLine();
		System.out.println("Enter a string s2: ");
		String s2 = scanner.nextLine();
		String match = getMatching(s1, s2);
		System.out.println(match);
		scanner.close();
		

	}
	
	public static String getMatching(String s1, String s2) {
		int i = 0;
		int matchLength = s2.length();
		char s2s = s2.charAt(0);
		while (i < s1.length()) {
			if (s1.charAt(i) == s2s) {
				String s1s = s1.substring(i, i);
				if (s1s.equals(s2)) {
					return "matched at index " + i;
					} else {
					
				}
			}
		}	i++;
		return "s2 is mot a substring of s1";
	}
}
