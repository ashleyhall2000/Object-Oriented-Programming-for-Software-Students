import java.util.Scanner;

public class Exercise22_01 {

	public static boolean main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a string: ");
		String base = input.next();
		int sub = 0;
		String maxSub = "";
		for (int i = 1; i < base.length(); i++) {
			String testSub = base.substring(sub, i + 1);
			if (testForString(testSub)) {
				if (testSub.length() > maxSub.length()) {
					maxSub = testSub;
				}
				else {
					sub++;
				}
			}
			System.out.println(maxSub);
			input.close();
		}
		static boolean testForString(String s) {
			for (int i = 0; i < s.length() - 1; i++) {
				if (s.charAt(i) > s.charAt(i + 1)) {
					return false;
				}
		
			}
			return true;
		} System.out.println("Maximum consecutive string is " + maxSub);
	} 

}
