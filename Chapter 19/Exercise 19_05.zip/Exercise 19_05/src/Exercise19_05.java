import java.util.Arrays;

public class Exercise19_05 {

	public static void main(String[] args) {
		Double[] values = new Double[] {4400.1, 1203.3, 3100.0, 18700.8, 4100.6};
		System.out.println("Max value: " + max(values) + " . from the list." + " \n" + Arrays.toString(values));
	}
	public static <E extends Comparable <E>> E max(E[] list) {
		E maxValue = list[0];
		for (int i = 1; i < list.length; i++) {
			if (list[i].compareTo(maxValue) > 0) {
				maxValue = list[i];
			
			}
		}
		return maxValue;
		
	}

}
