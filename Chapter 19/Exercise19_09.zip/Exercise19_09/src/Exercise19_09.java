import java.util.ArrayList;
import java.util.Arrays;

public class Exercise19_09 {

	public static void main(String[] args) {
		ArrayList<Double> doubleList = new ArrayList<>(Arrays.asList(5.0, 8.0, 7.0, 3.0, 1.0, 4.0, 9.0, 2.0, 10.0, 6.0));
		ArrayList<Integer> integerList = new ArrayList<>(Arrays.asList(55, 22, 66, 88, 99, 44, 33, 77, 100, 11));
		
		System.out.println("Before sorting: " + doubleList);
		sort(doubleList);
		System.out.println("After sorting: " + doubleList);
		System.out.println("Before sorting ArrayList: " + integerList);
		sort(integerList);
		System.out.println("After sorting: " + integerList);

	}
	public static <E extends Comparable<E>> void sort(ArrayList<E> list) {
		boolean loop = true;
		while (loop) {
			loop = false;
			for (int i = 0; i < list.size() - 1; i++) {
				if (list.get(i).compareTo(list.get(i + 1)) > 0) {
					loop = true;
					E temp = list.get(i);
					list.set(i, list.get(i + 1));
					list.set(i + 1, temp);
				}
			}
		}
	}

}
