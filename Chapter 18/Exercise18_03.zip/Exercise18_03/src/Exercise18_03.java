import java.util.Scanner;
public class Exercise18_03 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter two numbers:");
		int one = input.nextInt();
		int two = input.nextInt();
		System.out.println("The GCD of " + one + " and " + two + " is " + gcd(one,two));
		

	}
	static int gcd(int one, int two) {
		if (one % two == 0) {
			return two;
		}
		return gcd(two, one % two);
	}

}
