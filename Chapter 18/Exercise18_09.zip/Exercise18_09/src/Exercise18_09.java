import java.util.Scanner;

public class Exercise18_09 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a sentence to reverse: ");
		String sentence = input.nextLine().trim();
		reverseDisplay(sentence);
		input.close();

	}
	public static void reverseDisplay(String value) {
		if (!(value.length() == 0)) {
			System.out.println(value.charAt(value.length() - 1));
			reverseDisplay(value.substring(0,value.length() - 1));
		}
	}

}
