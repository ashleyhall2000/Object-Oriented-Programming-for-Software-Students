import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Exercise21_11 extends Application {
	static String yearInput;
	static String genderInput;
	static String nameSearch;
  private Map<String, Integer>[] mapForBoy = new HashMap[10];
  private Map<String, Integer>[] mapForGirl = new HashMap[10];
  
  private Button btFindRanking = new Button("Find Ranking");
  private ComboBox<Integer> cboYear = new ComboBox<>();
  private ComboBox<String> cboGender = new ComboBox<>();
  private TextField tfName = new TextField();
  private Label lblResult = new Label();
  
  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) {
    GridPane gridPane = new GridPane();
    gridPane.add(new Label("Select a year:"), 0, 0);
    gridPane.add(new Label("Boy or girl?"), 0, 1);
    gridPane.add(new Label("Enter a name:"), 0, 2);
    gridPane.add(cboYear, 1, 0);
    gridPane.add(cboGender, 1, 1);
    gridPane.add(tfName, 1, 2);
    gridPane.add(btFindRanking, 1, 3);
    gridPane.setAlignment(Pos.CENTER);
    gridPane.setHgap(5);
    gridPane.setVgap(5);
  
    BorderPane borderPane = new BorderPane();
    borderPane.setCenter(gridPane);
    borderPane.setBottom(lblResult);
    BorderPane.setAlignment(lblResult, Pos.CENTER);

    // Create a scene and place it in the stage
    Scene scene = new Scene(borderPane, 370, 160);
    primaryStage.setTitle("Exercise21_11"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage

    
    
  }
  
  public void createRanks(ArrayList<HashMap<String, String>> names, int gender) throws IOException {
	   for (int year = 2001; year <= 2010; year++) {
		      cboYear.getItems().add(year);
		      URL dataURL = new URL("http://liveexample.pearsoncmg.com/data/babynamesranking2001" + year + ".txt");
		      Scanner urlScanner = new Scanner(dataURL.openStream());
		      HashMap<String, String> map = new HashMap<>();
		      while(urlScanner.hasNextLine()) {
		    	  String[] line = urlScanner.nextLine().split("\\s+");
		    	  String ranking = line[0].trim();
		    	  map.put(line[gender].trim(), ranking);
		      }
		      names.add(map);
		      urlScanner.close();
		    }
		    cboYear.setValue(2001);
		        
		    cboGender.getItems().addAll("Male", "Female");
		    cboGender.setValue("Male");
		    
  }
 
  public void nameRanks(ArrayList<HashMap<String, String>> mapForBoy,
		  ArrayList<HashMap<String, String>> mapForGirl) {
	  	int mapIn =Integer.parseInt(yearInput.substring(2)) -1; 
	  	String rank = "";
	  	if (genderInput.equalsIgnoreCase("Male")) {
	  		HashMap<String, String> rankings = mapForBoy.get(mapIn);
	  	} else if (genderInput.equalsIgnoreCase("Female")) {
	  		HashMap<String, String> rankings = mapForGirl.get(mapIn);
	  	}
	  	lblResult.setText(findRanks(rank));
	  
  }
 public String findRanks(String rank) {
	  String showGender = genderInput.equals("Male") ? "Boy" : "Girl";
	  return showGender + "name" + nameSearch + "is ranked #" + rank + "in year" + yearInput;
	  
  }
  

  /**
   * The main method is only needed for the IDE with limited
   * JavaFX support. Not needed for running from the command line.
   */
  public static void main(String[] args) {
    launch(args);
  }
}