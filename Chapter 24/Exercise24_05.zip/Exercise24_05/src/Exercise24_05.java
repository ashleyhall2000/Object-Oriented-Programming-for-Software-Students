
public class Exercise24_05 {

	public static void main(String[] args) {
		GenericQueue<String> queue = new GenericQueue<String>();
			
		queue.enqueue("Ashley");
		
		System.out.print(queue.getSize());
		
		System.out.print(queue.dequeue());
		

	}

}
