
public class Exercise24_03 {

}
