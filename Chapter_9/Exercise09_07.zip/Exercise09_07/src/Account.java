import java.util.Date;
public class Account {
	private int id = 0;
	private double balance = 0;
	private double annualInterestRate = 0;
	private Date date =new Date();
	double deposit = 0;
	double withdraw = 0;
	public Account(int i, int j, double e) {
		this.id = i;
		this.balance = j;
		this.annualInterestRate = e;
		
	}
	public Account() {
		
	}
	public Date getDate() {
		return date;
		
	}
	public int getId() {
		return this.id;
		
	}
	public double getMonthlyInterestRate() {
		double monthlyInterestRate = (this.annualInterestRate / 12) / 100;
		return monthlyInterestRate;
		
	}
	public double getMonthlyInterest(double monthlyInterestRate) {
		double monthlyInterest = this.balance * monthlyInterestRate;
		return monthlyInterest;
		
	}
	public double getWithdraw(double withdraw) {
		this.balance = balance - withdraw;
		return balance;
	}
	public double getDeposit(double deposit) {
		this.balance = balance + deposit;
		return balance;
		
	}
	public void setBalance(double newBalance) {
		this.balance = newBalance;
	}
	public double getBalance() {
		return this.balance;
		
	}
}

