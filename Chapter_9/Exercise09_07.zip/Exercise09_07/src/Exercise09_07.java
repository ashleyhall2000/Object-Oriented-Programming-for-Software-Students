
public class Exercise09_07 {
	
	public static void main(String[] args) {
		Account myAccount = new Account( 1122, 20000, 4.5);
		myAccount.getMonthlyInterestRate();
		myAccount.getMonthlyInterest(myAccount.getMonthlyInterestRate());
		myAccount.setBalance(myAccount.getBalance());
		myAccount.getWithdraw(2500);
		myAccount.getDeposit(3000);
		myAccount.getBalance();
		System.out.println("Account Number: " + myAccount.getId() + "\t" + "Date: " + myAccount.getDate() + "\t" + "Balance: " + myAccount.getBalance() + "\t" + "Monthly Interest: " + myAccount.getMonthlyInterest(myAccount.getMonthlyInterestRate()));

	}

}
