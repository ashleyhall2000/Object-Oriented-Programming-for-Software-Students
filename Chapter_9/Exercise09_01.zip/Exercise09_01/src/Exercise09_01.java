
public class Exercise09_01 {
	public static void main(String args[]) {
		Rectangle myRectangle = new Rectangle(4,40);
		Rectangle myRectangle2 = new Rectangle(3.5,35.9);
		myRectangle.getArea();
		myRectangle.getPerimeter();
		myRectangle2.getArea();
		myRectangle.getPerimeter();
		myRectangle.getWidth();
		myRectangle.getHeight();
		myRectangle2.getWidth();
		myRectangle.getHeight();
		System.out.println("The rectangle has a width of:" +  myRectangle.width + "\t" + "Height of:" + myRectangle.height + "\t" + "Area of:" + myRectangle.getArea() + "\t\t\t" + "Perimeter of:" + myRectangle.getPerimeter());
		System.out.println("The rectangle has a width of:" +  myRectangle2.width + "\t" + "Height of:" + myRectangle2.height + "\t" + "Area of:" + myRectangle2.getArea() + "\t" + "Perimeter of:" + myRectangle2.getPerimeter());
	}

}
