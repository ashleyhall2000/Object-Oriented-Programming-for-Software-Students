
public class GeometricObject {
public static void main (String[] args) {
	Triangle triangle = new Triangle(5,6,7);
		System.out.println("Area of triangle: " + triangle.getArea());
		System.out.println("Perimeter of triangle: " + triangle.getPerimeter());
		System.out.println("Description of triangle: " + triangle.toString());
		
		
	
}
}
