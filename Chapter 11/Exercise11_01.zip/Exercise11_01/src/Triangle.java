
public class Triangle {
	double side1 = 1;
	double side2 = 1;
	double side3 = 1;
	
	public Triangle(double i, double j, double k) {
		side1 = i;
		side2 = j;
		side3 = k;
		
	}
	public double getArea() {
		double s = ((side1 + side2 + side3) / 2);
		return Math.sqrt(s * (s - side1) * (s - side2) * (s - side3));
		
	}
	public double getPerimeter() {
		return side1 + side2 + side3;
		
	}
	public String toString() {
		return ("Triangle: side1 = " + side1 + " side2 = " + side2 + " side3 = " + side3 + (" Color:green" + " true"));
	}
}
