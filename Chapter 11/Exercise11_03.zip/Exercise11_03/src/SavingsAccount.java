
class SavingsAccount extends Account {
	double overdraftLimit = 0;
	double balance = 0;
	public SavingsAccount(int j) {
		this.balance = j;
	}
}
