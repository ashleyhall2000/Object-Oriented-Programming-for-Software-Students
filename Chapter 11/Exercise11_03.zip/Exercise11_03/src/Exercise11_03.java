import java.util.Scanner;

public class Exercise11_03 {
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Account myAccount = new Account( 1, 100, 4.5);
		CheckingAccount checkingAccount = new CheckingAccount(100);
		SavingsAccount savingsAccount = new SavingsAccount(100);
		checkingAccount.setBalance(100);
		savingsAccount.setBalance(100);
		Account[] intArray = { new Account(0, 100, 4.5) , new Account(1, 100, 4.5), new Account(2, 100, 4.5), new Account(3, 100, 4.5) , new Account(4, 100, 4.5), new Account(5, 100, 4.5), new Account(6, 100, 4.5), new Account(7, 100, 4.5), new Account(8, 100, 4.5), new Account(9, 100, 4.5)};
		System.out.println("Enter an id:" );
		double ids = input.nextDouble();
		System.out.println("Main Menu:");
		System.out.print("1: Check Balance" + "\t" + "2: Withdraw" + "\t" + "3: Deposit" + "\t" + "4: Exit");
		double menuop = input.nextDouble();
		while (menuop !=4) {
			
			if(menuop == 1) {
				System.out.println("Checking Account: 1" + "\t" + "Savings Account: 2");
				double option = input.nextDouble();
				if(option == 1) {
					System.out.println(checkingAccount.getBalance());
				}
				if(option == 2) {
					System.out.println(savingsAccount.getBalance());
				}
			}
			if(menuop == 2) {
				System.out.println("Checking Account: 1" + "\t" + "Savings Account: 2");
				double option = input.nextDouble();
				if(option == 1) {
					System.out.println("Enter a withdraw amount: ");
					double with = input.nextDouble();
					if((checkingAccount.getBalance() - with) < checkingAccount.overdraftLimit) {
						System.out.println("You cannot overdraft this account further.");
						
					} else {
					System.out.println(checkingAccount.getWithdraw(with));
					}
				}
				if(option == 2) {
					System.out.println("Enter a withdraw amount: ");
					double with = input.nextDouble();
					if((savingsAccount.getBalance() - with) < savingsAccount.overdraftLimit) {
						System.out.println("You cannot overdraft this account.");
					} else {
					System.out.println(savingsAccount.getWithdraw(with));
					}
				}
			}
			if(menuop == 3) {
				System.out.println("Checking Account: 1" + "\t" + "Savings Account: 2");
				double options = input.nextDouble();
				if(options == 1) {
					System.out.println("Enter a deposit amount: ");
					double depo = input.nextDouble();
					System.out.println(checkingAccount.getDeposit(depo));
				}
				if(options == 2) {
					System.out.println("Enter a deposit amount: ");
					double depo = input.nextDouble();
					System.out.println(checkingAccount.getDeposit(depo));
				}
			}
			System.out.println("Main Menu:");
			System.out.print("1: Check Balance" + "\t" + "2: Withdraw" + "\t" + "3: Deposit" + "\t" + "4: Exit");
			menuop = input.nextDouble();
		}	
	}
}