
class CheckingAccount extends Account {
	double overdraftLimit = -500;
	double balance = 0;
	public CheckingAccount() {
		
	}
	public CheckingAccount(int j) {
		this.balance = j;
	}
}
