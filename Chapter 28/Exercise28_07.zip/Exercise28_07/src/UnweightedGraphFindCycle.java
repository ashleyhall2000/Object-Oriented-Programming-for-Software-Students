import java.util.*;
public class UnweightedGraphFindCycle<V> extends UnweightedGraph{

	public List<Integer> getACycle(int u) {
		List<Integer> potentialCycle = dfs.(u).getSearchOrder();
			for(int i = 2; i < potentialCycle.size(); i++) {
				List<Integer> neighbor = getNeighbor(potentialCycle.get(i));
				if(neighbors.contains(u)) {
					List<Integer> cycle = new ArrayList<>();
					for(int j = 0; j < i + 1; j++)
						cycle.add(potentialCycle.get(j));
							cycle.add(u);
							return cycle;
				}
			}
			return null;
 	}
}
