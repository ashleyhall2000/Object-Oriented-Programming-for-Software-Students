import java.util.Scanner;

public class Exercise10_07 {
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Account myAccount = new Account( 1, 100, 4.5);
		Account[] intArray = { new Account(0, 100, 4.5) , new Account(1, 100, 4.5), new Account(2, 100, 4.5), new Account(3, 100, 4.5) , new Account(4, 100, 4.5), new Account(5, 100, 4.5), new Account(6, 100, 4.5), new Account(7, 100, 4.5), new Account(8, 100, 4.5), new Account(9, 100, 4.5)};
		System.out.println("Enter an id:" );
		double ids = input.nextDouble();
		System.out.println("Main Menu:");
		System.out.print("1: Check Balance" + "\t" + "2: Withdraw" + "\t" + "3: Deposit" + "\t" + "4: Exit");
		double menuop = input.nextDouble();
		while (menuop !=4) {
			
			if(menuop == 1) {
				System.out.println(myAccount.getBalance());
			}
			if(menuop == 2) {
				System.out.println("Enter a withdraw amount: ");
				double with = input.nextDouble();
				System.out.println(myAccount.getWithdraw(with));
			}
			if(menuop == 3) {
				System.out.println("Enter a deposit amount:");
				double deposits = input.nextDouble();
				System.out.println(myAccount.getDeposit(deposits));
			}
			System.out.println("Main Menu:");
			System.out.print("1: Check Balance" + "\t" + "2: Withdraw" + "\t" + "3: Deposit" + "\t" + "4: Exit");
			menuop = input.nextDouble();
		}	
	}
}
