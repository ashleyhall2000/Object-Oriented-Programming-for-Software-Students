package exercise10_3;

public class MyInteger {
	int value = 0;
	
	public MyInteger() {
		
	}
	
	public int isEven() {
		return value;
		
	}
	public int isOdd() {
		return value;
		
	}
	public int isPrime() {
		return value;
		
	}
	public static boolean isEven(int value) {
		return value % 2 == 0;
		
	}
	
	public static boolean isOdd(int value) {
		return value % 2 != 0;
		
	}
	
	
	public static boolean isPrime(int value) {
		for(int i = 0; i <= value; i++) {
			if (value % i == 0) {
				return true;
			}
			else {
				return false;
			}
		}
		return false;
	}
	public static boolean isEven(MyInteger value) {
		boolean result = isEven(value.value);
		return result;

		
	}
	public static  boolean isOdd(MyInteger value) {
		boolean result =isOdd(value.value);
		return result;
	}
	public static boolean isPrime(MyInteger value) {
		boolean result = isPrime(value.value);
		return result;
	}
	public int equals(int value) {
		return value;
	}
	public int equals(MyInteger value) {
		return 0;
		
	}
	public static void parseInt(char[] array) {
		int value = 0;
		for(int i = 0; i < array.length; i++) {
			
		}
	}
	public static void parseInt(String string) {
		int value = Integer.parseInt(string);
		
	}
	public int getInt(int value) {
		return value;
	}

}
