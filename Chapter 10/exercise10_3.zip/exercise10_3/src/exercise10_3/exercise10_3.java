package exercise10_3;

public class exercise10_3 {
public static void main(String args []) {
	MyInteger myInteger = new MyInteger();
			System.out.println(myInteger.isEven(5));
			System.out.println(myInteger.isOdd(5));
			System.out.println(myInteger.isPrime());
			System.out.println(myInteger.equals(5));
			char[] charArray = new char[] {5,8,6,2,7,11,17,12,1,0};
			String str = new String (charArray);
			
			
			
			
	}
}
