import javafx.stage.Stage;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javafx.application.Application;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.scene.*;
import java.util.Random;


public class Exercise14_28 extends Application {
	@Override
  public void start(Stage primaryStage) {
		ClockPane clockPane = new ClockPane();
		clockPane.setHour((int)(Math.random() * 12));
		clockPane.setMinute((int)(Math.random() * 60));
		clockPane.setSecond((int)(Math.random() * 60));
		clockPane.paintClock();
		
        //clockPane.getChildren().add(btn);
        primaryStage.setScene(new Scene(clockPane, 300, 250));
        primaryStage.show();
		
	}
	/**
	 * The main method is only needed for the IDE with limited
	 * JavaFX support. Not needed for running from the command line.
	 */
	public static void main(String[] args) {
		launch(args);
	}
}
