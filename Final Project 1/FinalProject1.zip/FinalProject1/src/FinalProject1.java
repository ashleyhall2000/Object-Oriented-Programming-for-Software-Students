import javafx.stage.Stage;
import javafx.scene.layout.VBox;
import javafx.layout.HBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.Scene;
import javajx.geometry.Pos;
import javafx.geometry.Insets;
import javafx.beans.property.SimpleStringProperty;
import javafx.application.Application;

public class FinalProject1 extends javafx.application.Application {

	
	public void start(Stage primaryStage) throws Exception {
		SimpleStringProperty displayResults = new SimpleStringProperty();
		
		VBox mainBox = new Vbox(5);
		
		HBox investmentAmountBox = new TextField();
		Label amountLabel = new Label("Amount of Investment: ");
		TextField amountField = new TextField();
		Hbox.setMargin(amountLabel, new Insets(10, 5, 5, 1));
		HBox.setMargin(amountField, new Insets(10, 5, 5, 1));
		investmentAmountBox.getChildren().addAll(amountLabel, amountField);
		
		HBox numberOfYearsBox = new HBox(5);
		Label yearsLabel = new Label("Amount of Years: ");
		TextField yearsField = new TextField();
		HBox.setMargin(yearsField, new Insets(1, 5, 5, 1));
		HBox.setMargin(yearsLabel, new Insets(1, 5, 5, 1));
		numberOfYearsBox.getChildren().addAll(yearsLabel, yearsField);
		
		HBox interestRateBox = new HBox(5);
		Label interestLabel = new Label("Interest Rate (Annual): ");
		TextField interestField = new TextField();
		HBox.setMargin(interestField, new Insets(1, 5, 5, 1));
		HBox.setMargin(interestLabel, new Insets(1, 5, 5, 1));
		interestRateBox.getChildren().adAll(interestLabel, interestField);
		
		HBox futureValueBox = new HBox(5);
		Label futureValLabel = new Label("Future Value: ");
		TextField resultField = new TextField();
		
		HBox.setMargin(futureValLabel, new Insets(1, 5, 5, 5));
		HBox.setMargin(resultField, new Insets(1, 5, 5, 5));
		
		resultField.textProperty().bind(displayResult);
		futureValueBox.getChildren().addAll(futureValLabel, resultField);
		
		HBox bottomBox = new Hbox(5);
		Button calculateBtn = new Button("Calculate Total");
		bottomBox.getChildren().add(calculateBtn);
		HBox.setMargin(calculateBtn, new Insets(1, 10, 0, 0));
		calculateBtn.setOnAction(e -> {
			double futureValue = cauculateFutureValue(amountField.getText(), yearsField.getText(), interestField.getText());
			displayResult.set(String.format("$%.2f", futureValue));
		});
		
		bottomBox.setAlignment(Pos.BOTTOM_RIGHT);
		mainBox.getChildren().adAll(investmentAmountBox, numberOfYearsBox, interestRateBox, futureValueBox, bottomBox);
		
		Scene scene = new Scene(mainBox, 500, 300);
		primaryStage.setScene(scene);
		primaryStage.setTitle(getClass().getName());
		primaryStage.show();
		
	}
	public static void main(String[] args) {
		launch(args);

	}
	double calculateFutureValue(String investmentAmount, String numYears, String annualInterestRate) {
		double amount = Double.parseDouble(investmentAmount);
		int years = Integer.parseInt(numYears);
		double monthlyRate = Double.parseDouble(annualInterestRate) / 100 / 12; 
		double wild = Math.pow((1 + monthlyRate), (years * 12.0));
		return amount * wild;
	}

}
