public class GeometricObject {
public static void main (String[] args) {
	Octagon octagon = new Octagon(4, 4, 4, 4, 4, 4, 4, 4);
		System.out.println("Area of Octagon: " + octagon.getArea());
		
	
}
}
