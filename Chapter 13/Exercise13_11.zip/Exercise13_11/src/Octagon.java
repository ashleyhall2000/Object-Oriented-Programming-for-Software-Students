
class Octagon extends GeometricObject {
	

		double side1 = 1;
		double side2 = 1;
		double side3 = 1;
		double side4 = 1;
		double side5 = 1;
		double side6 = 1;
		double side7 = 1;
		double side8 = 1;
		boolean fill = true;
		
		public Octagon(double i, double j, double k, double l, double m, double n, double o, double p) {
			side1 = i;
			side2 = j;
			side3 = k;
			side4 = l;
			side5 = m;
			side6 = n;
			side7 = o;
			side8 = p;
			
		}
		public double getArea() {
			return ((2 * side1 * side2) * (1 + sqrt(2)));
			
			
				
		}
		private int sqrt(int i) {
			return 0;
		}
		public static void howToColor() {
		
		}
		public String toString() {
			return ("Octagon: side1 = " + side1 + " side2 = " + side2 + " side3 = " + side3 + "side4 = " + side4 + " side5 = " + side5 + " side6 = " + side6 + " side7 = " + side7 + "side8 = " + side8 + (" Color:green , " + fill + " , Colorable"));
			}
		}